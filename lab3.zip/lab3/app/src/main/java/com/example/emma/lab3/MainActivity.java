package com.example.emma.lab3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.LinkedList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    public static String myRfid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final String originIP = "192.168.2.110";
        final String destIP = "192.168.2.152";

        //Cada 10 segons crida a les tasques
        Timer timerAsync = new Timer();
        TimerTask timerTaskAsync = new TimerTask() {
            @Override
            public void run() {
                MyTaskOrigin taskorigin = new MyTaskOrigin(originIP);
                MyTaskDest taskdest = new MyTaskDest(destIP);
                taskorigin.execute();
                taskdest.execute();
            }
        };
        timerAsync.schedule(timerTaskAsync, 0, 5000);
    }
}

